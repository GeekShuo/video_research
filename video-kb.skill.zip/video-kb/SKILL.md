---
name: video-kb
description: |-
  This skill operates the local "video_kb" project to build and query a
  video/article knowledge base. Use it when the user wants to: crawl and
  transcribe Bilibili/YouTube videos (or fetch articles) on a topic and store
  them in a local Chroma vector DB; run RAG Q&A over that knowledge base; or
  run the cross-platform domain research agent that searches B站/YouTube/知乎/
  小红书/抖音/微博, filters by relevance, ingests, and writes a 《领域研究报告》.
  Trigger phrases include "build a knowledge base from videos on X", "transcribe
  and index these videos", "research the field of Y and write a report", or
  "answer questions from my video knowledge base". It also encodes critical,
  non-obvious environment fixes (JS runtime for yt-dlp, cublas DLL for GPU
  whisper, YouTube login cookies, the bundled Python to use) — read
  references/gotchas.md before running anything.
---

# video-kb

## Overview

Drive the local `video_kb` project (located at `d:/project/video_kb/` relative to this
skill, i.e. the `video_kb/` repo root) to turn videos/articles into a queryable
knowledge base, and to run a cross-platform domain research agent. The project
does: 下载(yt-dlp) → 转写(本地 faster-whisper GPU) → 视觉理解(API) → 合并笔记(LLM)
→ 向量库(Chroma) → RAG 问答, plus a research-agent mode that auto-searches and
reports on a domain.

## When to use

- Build a knowledge base from a topic: "把陆奇的演讲做成知识库", "抓取并转写这些 YouTube 视频".
- Query an existing knowledge base: "他在哪一期讲过 XXX？", "总结他对 Y 的观点".
- Run the research agent: "研究一下具身智能，出一份报告", "AI 创业领域现在有哪些大牛".

## Critical: read this before running

This project has several environment traps that will silently produce broken
output (image-only downloads, no GPU, login walls). **Always read
`references/gotchas.md` first.** In short:

1. Use the **bundled Python**, not system `python`:
   `C:\Users\xqer\.workbuddy\binaries\python\versions\3.11.9\python.exe`
2. GPU transcription needs the cublas DLL fix that lives in
   `d:/project/video_kb/transcribe.py` (`_add_nvidia_dll_path`) — keep it.
3. yt-dlp needs an external JS runtime (node) for YouTube; provided by
   `d:/project/video_kb/ytdlp_runtime.py`.
4. YouTube now requires a **login state** (cookies). See gotchas for the
   `--cookies-from-browser` / `cookies.txt` workflow.

## Core capabilities

### 1. Build knowledge base + Q&A
- Single video: `python d:/project/video_kb/run_crawl.py video URL`
- Batch crawl (B站/图文 configured in `d:/project/video_kb/run_crawl.py`): `python d:/project/video_kb/run_crawl.py videos` / `articles`
- Backfill degraded videos: `python d:/project/video_kb/backfill.py run --platform youtube --topic 主题 --cookies-from-browser chrome --no-fallback` (see `references/commands.md`)
- Query: `from agent import ask; ask("你的问题")`

### 2. Domain research agent
- `python d:/project/video_kb/run_research.py "领域" --platforms bili,youtube,zhihu,xhs,dy`
- Produces `d:/project/video_kb/data/research/raw/...` (plan/candidates/filter JSON) and
  `d:/project/video_kb/data/reports/领域_日期.md`, and ingests everything into the KB.

### 3. Gotchas & environment (bundled knowledge)
- `references/gotchas.md` — JS runtime, cublas DLL, YouTube login cookies,
  bundled Python, background-transcription subprocess, MediaCrawler isolation.
- `references/commands.md` — full CLI reference for every entry point.
- `references/workflow.md` — step-by-step flows for both modes.

## Notes
- `knowledge_base.py` deletes old data by `video_id` before ingest, so re-running
  a successful crawl/backfill auto-cleans degraded 图文 entries — no manual cleanup.
- Keep usage personal/educational; respect platform ToS and copyright.
