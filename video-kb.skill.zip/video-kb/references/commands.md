# video_kb — 命令参考

所有命令都用内置 Python 执行：
```
$py = "C:\Users\xqer\.workbuddy\binaries\python\versions\3.11.9\python.exe"
cd d:/project/video_kb
```

---

## d:/project/video_kb/run_crawl.py — 主抓取/转写入库入口

| 命令 | 说明 |
|---|---|
| `python d:/project/video_kb/run_crawl.py video <url>` | 处理**单个**视频 URL：下载→转写→入库。支持 `?t=分:秒` 起播。 |
| `python d:/project/video_kb/run_crawl.py videos` | 按 `d:/project/video_kb/run_crawl.py` 里配置的 B站视频 URL 列表批量抓取。 |
| `python d:/project/video_kb/run_crawl.py articles` | 按配置的图文 URL 列表抓取（知乎/公众号等），含 B站专栏。 |
| `python d:/project/video_kb/run_crawl.py synthesize` | 仅跑 LLM 合并笔记（用已转写、未合并的视频）。 |

YAML 配置键（`d:/project/video_kb/run_crawl.py` 顶部 `CONFIG`）：`bili_urls` / `article_urls` /
`douyin_url` / `max_articles` / `max_bili` / `model`（whisper）/ `platform`（bili/youtube）/
`no_visual`（跳过视觉）/ `youtube_urls` / `topic`。

---

## d:/project/video_kb/backfill.py — 补爬 / 重试降级视频

| 命令 | 说明 |
|---|---|
| `python d:/project/video_kb/backfill.py list --platform youtube --topic <主题>` | 列出该主题下待补爬的视频（不下载）。 |
| `python d:/project/video_kb/backfill.py run --platform youtube --topic <主题>` | 执行补爬（默认从 `cookies.txt`）。 |
| `--limit N` | 只处理前 N 条。 |
| `--max-duration N` | 跳过时长 > N 秒的视频（转写慢）。 |
| `--cookies-from-browser chrome` | 从已登录浏览器读**实时** cookie（Chrome 须先完全退出，否则锁库）。 |
| `--no-fallback` | 下载失败直接跳过，不产生降级图文垃圾。 |

示例（YouTube 当前需要登录态）：
```
python d:/project/video_kb/backfill.py run --platform youtube --topic ai模拟面试 --cookies-from-browser chrome --no-fallback
```

---

## d:/project/video_kb/run_research.py — 领域研究 Agent（跨平台搜索→筛选→入库→报告）

| 参数 | 默认 | 说明 |
|---|---|---|
| `<topic>`（位置参数） | 必填 | 研究领域，如 `具身智能`。 |
| `--platforms` | `bili,youtube,zhihu,xhs,dy` | 逗号分隔的平台。 |
| `--max-per-kw` | 5 | 每个关键词最多取多少条候选。 |
| `--top` | 6 | 最终精排保留多少条写入报告。 |
| `--threshold` | 0.55 | 相关性阈值，低于则丢弃。 |
| `--rounds` | 2 | 关键词扩展轮数。 |
| `--no-video` | 关 | 只做图文，不下载/转写视频（快、省算力）。 |
| `--dry-run` | 关 | 只打印计划出的关键词+候选，不抓取。 |
| `--urls` | 无 | 直接给 URL 列表，跳过搜索。 |

输出：
- `d:/project/video_kb/data/research/raw/<topic>_<ts>/`：`plan.json`、`candidates.json`、`filter.json`
- `d:/project/video_kb/data/reports/<topic>_<日期>.md`：《领域研究报告》
- 全部候选自动入库到 KB。

示例：
```
python d:/project/video_kb/run_research.py "具身智能" --platforms bili,youtube,zhihu --no-video
python d:/project/video_kb/run_research.py "AI 创业" --platforms bili,youtube --top 8
```

---

## agent.py — RAG 问答

```python
from agent import ask
ask("他在哪一期讲过 agent 的演化？")   # 返回文本答案（含引用来源）
```
也可 `python -c "from agent import ask; print(ask('...'))"`。

---

## 视觉理解 / 转写相关

- 视觉理解需 `GEMINI_API_KEY` 或 `KIMI_API_KEY`（`d:/project/video_kb/.env`）。
- 转写走 `transcribe.py` 的 `_transcribe_worker.py` 子进程（见 gotchas #5）。

---

## 常见故障速查

| 现象 | 原因 | 处理 |
|---|---|---|
| 只有 storyboard 图片、无音频 | yt-dlp 缺 JS 运行时 | 见 gotchas #3 |
| `cublas64_12.dll ... not found` | nvidia DLL 路径没加 | 见 gotchas #2，勿删 `_add_nvidia_dll_path` |
| `Sign in to confirm you're not a bot` | YouTube 要登录态 | 见 gotchas #4，关 Chrome 后用 `--cookies-from-browser` |
| `Could not copy Chrome cookie database` | Chrome 没退出、锁库 | 完全退出 Chrome 再跑 |
| 中文/emoji 标题报 `UnicodeEncodeError` | GBK 控制台 | 设 `$env:PYTHONIOENCODING='utf-8'` |
