# video_kb — 关键避坑知识（务必先读）

本项目的每次"跑不起来"几乎都出自下面这 5 个环境陷阱。按顺序排查。

---

## 1. 必须用内置 Python，不要用系统 `python`

正确解释器（依赖都装在这里）：

```
C:\Users\xqer\.workbuddy\binaries\python\versions\3.11.9\python.exe
```

- 系统 `python` 没有 faster-whisper / chromadb / nvidia-* 依赖。
- cublas DLL 修复（见第 2 条）依赖这个解释器的 `site` 路径，**换解释器会失效**。
- 所有命令示例里的 `python` 都指这个绝对路径。

---

## 2. GPU 转写 cublas DLL 修复（已固化在 `transcribe.py`）

现象：`transcribe.py` 真正做 GEMM 时报
`Library cublas64_12.dll is not found or cannot be loaded`。

根因：该内置 Python 的 `site.getsitepackages()[0]` 返回的是 **Python 根目录**
而非 `Lib\site-packages`，导致 nvidia 的 `bin` 目录没被加进 DLL 搜索路径。

修复（`transcribe.py` 里的 `_add_nvidia_dll_path()`，**不要删**）：
遍历所有 site-packages + usersite，把 `nvidia/*/bin` 用 `os.add_dll_directory`
加入，并补 `PATH`。

- 显卡驱动 610.74 足够新，cublas 本身能加载，问题只在 DLL 搜索路径。
- 模型用 `medium` int8（RTX 2060）。**设计为 GPU-only，没有 CPU 回退**。
- 速度参考：small 模型 134 分钟音频，GPU 约 9 分钟（纯 CPU 约 1.5 小时）。

---

## 3. yt-dlp 必须配外部 JS 运行时（解 YouTube EJS/n-sig 挑战）

现象：下载只剩 `storyboard`（storyboard 图片格式），拿不到音频/视频 → 视频被
降级成图文。

根因：YouTube 的 EJS/n-sig 挑战需要外部 JS 引擎解算，yt-dlp 自带的不够。

修复：项目里有 `ytdlp_runtime.py`，提供 `js_runtime_opts()`，返回
`--js-runtimes node:<绝对路径>`。使用的 node：

```
C:\Users\xqer\Tools\node\node-v23.9.0-win-x64\node.EXE
```

`download_audio()` 已自动 `**js_runtime_opts()`，无需手动传。若换机器，更新
`ytdlp_runtime.py` 里的 NODE 路径或设环境变量 `YTDLP_JS_RUNTIME`。

---

## 4. YouTube 登录态（cookie）—— 当前最大的 blocker

现象：`[youtube] ...: Sign in to confirm you're not a bot. Use --cookies`。

YouTube 现在对每次请求都要求**有效的实时登录态**。注意：

- `cookies.txt` 是多家站点（百度/B站/淘宝/Reddit/Google…）拼在一起的"全家桶"，
  里面虽有 `__Secure-3PSID` 等，但 `__Secure-3PSIDTS` 这类短期验证 token 由
  Google 服务端动态校验，**即使名义没过期也会被服务端判定失效**。所以"看起来新鲜"
  的 cookies.txt 实际可能已失活。
- 浏览器直读 cookie：`--cookies-from-browser chrome`（或 edge）能拿到最新
  PSIDTS，但**该浏览器必须先完全退出**（包括后台进程，否则
  `Could not copy Chrome cookie database` 锁库）。
- Edge 还可能 `DPAPI 解密失败`。
- 重导出可靠 cookie：用浏览器扩展「Get cookies.txt LOCALLY」在 YouTube 登录状态
  下导出，覆盖 `d:/project/video_kb/yt_cookies.txt`（或 `cookies.txt`），确保含
  `.youtube.com` 的 `__Secure-3PSIDTS` 最新值。

降级行为：`ingest_video_result()` 在下载失败时会**降级成图文入库**（标题+摘要）。
加参数 `no_fallback=True` 可改为**直接跳过、不产生图文垃圾**
（`d:/project/video_kb/backfill.py` 对应开关 `--no-fallback`，见 `commands.md`）。

> 重跑成功的抓取会按 `video_id` 先删旧数据，所以之前误入的降级图文会被自动清掉。

---

## 5. 转写必须放在独立子进程（后台）

- 转写在 `_transcribe_worker.py` 子进程里跑，**不要在主进程里直接调**，否则
  chromadb → onnxruntime 会互相干扰导致崩溃。
- `d:/project/video_kb/run_crawl.py` / `d:/project/video_kb/backfill.py` 已封装好子进程调用，直接跑入口即可。

---

## 6. MediaCrawler 子进程隔离（知乎/小红书/抖音/微博）

- 这些平台走 `d:/project/video_kb/MediaCrawler/`，作为**子进程**、用其自带 venv
  （`d:/project/video_kb/MediaCrawler/venv`）运行，与主项目环境隔离。
- 首次用 xhs/dy/zhihu/wb 需浏览器扫码登录，登录态缓存在
  `d:/project/video_kb/MediaCrawler/browser_data/`；之后会复用。
- 引擎在 `d:/project/video_kb/MediaCrawler/项目源码/ d:/project/video_kb/MediaCrawler/`（`main.py` 的 `media_crawler`
  函数在 `d:/project/video_kb/run_crawl.py` 里被调用）。

---

## 7. Windows GBK 控制台

脚本启动时会 `reconfigure` stdout 为 utf-8，避免中文/emoji 标题触发
`UnicodeEncodeError`。若自行写入口脚本，记得加上；或在命令前设
`$env:PYTHONIOENCODING='utf-8'`。

---

## 8. API Key 配置

视觉理解（看视频画面文字）需要 `GEMINI_API_KEY` 或 `KIMI_API_KEY`，写在
`d:/project/video_kb/.env`（`load_dotenv()`）。无 Key 时跳过视觉理解，仅用音频转写+标题。
