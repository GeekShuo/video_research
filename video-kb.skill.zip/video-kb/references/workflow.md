# video_kb — 工作流

两套主流程。开始前一律先读 `gotchas.md`。

---

## 流程 A：建库 + 问答

### A0. 前置检查
1. 用内置 Python（gotchas #1）。
2. 确认 `ytdlp_runtime.py` 的 node 路径存在（gotchas #3）。
3. GPU 转写的 cublas 修复在 `transcribe.py`，不要动（gotchas #2）。
4. YouTube 需要登录态：先完全退出 Chrome，或用有效 `cookies.txt`（gotchas #4）。

### A1. 单个视频
```
cd d:/project/video_kb
$py d:/project/video_kb/run_crawl.py video "<YouTube/B站 URL>"
# 可选起播点： url?t=12:30
```

### A2. 批量按主题抓取
- 编辑 `d:/project/video_kb/run_crawl.py` 顶部 `CONFIG` 的 `bili_urls` / `article_urls` / `youtube_urls`。
- 跑 `python d:/project/video_kb/run_crawl.py videos` 或 `python d:/project/video_kb/run_crawl.py articles`。

### A3. 补爬（针对 YouTube 登录态问题最常用）
```
# 先确认目标
python d:/project/video_kb/backfill.py list --platform youtube --topic "<主题>"
# 关掉 Chrome 后用浏览器实时 cookie，且禁止降级
python d:/project/video_kb/backfill.py run --platform youtube --topic "<主题>" --cookies-from-browser chrome --no-fallback
# 仅图文/不转写：加 --no-video；跳过长视频：--max-duration 1200
```

### A4. 合并笔记（可选，仅 LLM 整理）
```
python d:/project/video_kb/run_crawl.py synthesize
```

### A5. 问答
```python
from agent import ask
print(ask("他关于 agent 的核心观点是什么？"))
```

### A6. 清理降级垃圾
重跑成功的抓取会按 `video_id` 先删旧数据，**无需手动清理**。若之前误入降级图文，
重新成功跑一遍同 URL 即可覆盖。

---

## 流程 B：领域研究 Agent（d:/project/video_kb/run_research.py）

给定领域 → 自动扩展关键词 → 跨平台搜索 → 相关性筛选 → 入库 → 出报告。

### B1. 先 dry-run 看计划
```
python d:/project/video_kb/run_research.py "具身智能" --platforms bili,youtube,zhihu --dry-run
```
确认关键词和候选合理，再正式跑。

### B2. 正式运行
```
# 快、省算力：只图文
python d:/project/video_kb/run_research.py "具身智能" --platforms bili,youtube,zhihu --no-video
# 含视频转写（更慢、更费力）
python d:/project/video_kb/run_research.py "AI 创业" --platforms bili,youtube --top 8
# 直接给 URL，跳过搜索
python d:/project/video_kb/run_research.py "我的主题" --urls "https://..." "https://..."
```

### B3. 产出
- `d:/project/video_kb/data/research/raw/<topic>_<ts>/`：`plan.json` / `candidates.json` / `filter.json`
- `d:/project/video_kb/data/reports/<topic>_<日期>.md`：《领域研究报告》（背景/大牛/趋势/机会/风险/来源）
- 所有候选已自动入库，可直接用 `agent.ask` 追问细节。

### B4. 首次用某平台
知乎/小红书/抖音/微博 首次需浏览器扫码登录（MediaCrawler，见 gotchas #6），
登录态缓存在 `d:/project/video_kb/MediaCrawler/browser_data/`，之后复用。

---

## 平台对照

| 平台 | 走哪条链路 | 是否需要登录 |
|---|---|---|
| B站 视频 | `d:/project/video_kb/run_crawl.py videos` / `backfill`(bili) | 一般公开可下 |
| B站 专栏 | `d:/project/video_kb/run_crawl.py articles` | 一般公开 |
| YouTube | `d:/project/video_kb/backfill.py --platform youtube` | **需要登录态 cookie** |
| 知乎/小红书/抖音/微博 | `d:/project/video_kb/run_research.py` → MediaCrawler | 首次需扫码 |

---

## 典型用户意图 → 命令

- "把陆奇的演讲做成知识库" → 收集 B站/YouTube URL → A2 / A3。
- "这几条视频转写入库" → A1 逐条，或 A2 批量。
- "研究一下具身智能" → B2。
- "他在哪一期讲过 XXX" → A5 / B3 后 `agent.ask`。
